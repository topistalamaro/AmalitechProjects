<?php
header("location: ../../index");

?>