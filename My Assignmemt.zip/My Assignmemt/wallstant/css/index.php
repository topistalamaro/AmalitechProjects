<?php
header('location: ../home');
?>